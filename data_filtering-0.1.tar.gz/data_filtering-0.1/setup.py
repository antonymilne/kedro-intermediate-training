# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name="data_filtering",
    version="0.1",
    description="Micro-package `data_filtering`",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
)
